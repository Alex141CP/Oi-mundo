import json

def lambda_handler(event, context):
        html_response = """<!DOCTYPE html>
            <html lang="pt-BR">
            
            <head>
                <meta charset="UTF-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                <title>Compre Sua Peça</title>
                <style>
                    /* Importe a fonte Open Sans do Google Fonts */
                    @import url("https://fonts.googleapis.com/css?family=Open+Sans:400,700&display=swap");
            
                    body {
                        background-color: #3e1749;
                        display: flex;
                        flex-direction: column;
                        justify-content: center;
                        align-items: center;
                        overflow-x: hidden;
                        text-decoration: none;
                        /* height: 100vh; */
                        margin: 0;
                        font-family: "Open Sans", Arial, sans-serif;
                    }
            
                    h1 {
                        text-align: center;
                        padding-top: 10px;
                        color: #fff;
                        font-size: 40px;
                    }
            
                    h2 {
                        text-align: center;
                        color: #e16520;
                        font-size: 30px;
                    }
                    
                    h4 {
                        text-align: center;
                        color: #e16520;
                    }
            
                    p {
                        text-align: center;
                        color: #fff;
                        font-size: 20px;
                    }
            
                    button {
                        background-color: #e16520;
                        padding: 12px;
                        border-radius: 50px;
                        border: #fff 1px solid;
                    }
            
                    button :hover {
                        padding-inline: 18px;
                        padding: 12px;
                        border-radius: 50px;
                        color: #3e1749;
                        transform: scale(1.1);
                        transition: all 0.5s;
                    }
            
                    .btn-ajuda {
                        text-decoration: none;
                        color: #fff;
                        font-weight: bold;
                        font-size: 15px;
                    }
                </style>
            </head>
            
            <body>
                <h1>CSP Auto Chat</h1>
                <h2>BEM VINDO AO FUTURO!</h2>
                    <!-- Widget Env Script -->
                <script>
                  var Zaia = {
                    AgentURL: "https://platform.zaia.app/embed/chat/16759"
                  };
                </script>
                
                <!-- Widget Loader Script -->
                <script src="https://cdn.zapgpt.com.br/widget-loader.js"></script>
                  <body>
                    <iframe 
                      src="https://platform.zaia.app/embed/chat/16759"
                      style="border: none; width: 400px; height: 600px; border-radius: 20px; border: 1px #eee solid;">
                    </iframe>
                  </body>


                <p>O Agente de IA especialista no seu estoque!</p>
                <h4>Vamos juntos continuar inovando no mercado automotor.</h4>

                <br /><br />
                <button>
                    <a class="btn-ajuda" href="https://api.whatsapp.com/send?phone=5511944909162" target="_blank">Preciso de
                        Ajuda!</a>
                </button>
                <br /><br /><br />
            </body>
            
            </html>
            """
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "text/html"
            },
            "body": html_response
        }